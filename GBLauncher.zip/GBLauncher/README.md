# DMG Launcher: Game Boy-style dumbphone launcher (Android)

Open in Android Studio (Koala+), sync Gradle, Run. Press Home -> "DMG Launcher" -> Always.

Home: MUSIC and VIDEO are pinned at the top of the app list.
- Tap/A launch, long-press App info/Uninstall, SELECT search, START Settings

Music: ▲▼ select, A play/pause, ◀ prev (restarts if >3s in), ▶ next,
       SELECT shuffle, START stop, B back. Music keeps playing after you leave the screen.
Video: tap a file to play full screen. Tap the picture for controls (-10s, pause, +10s, TINT).
       TINT maps the video onto the 4 greens. D-pad ◀▶ seek, Back returns to the list.
