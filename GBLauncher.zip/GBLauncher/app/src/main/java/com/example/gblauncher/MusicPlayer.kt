package com.example.gblauncher

import android.content.Context
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.os.PowerManager

/** Process-wide player so music keeps going after you leave the Music screen. */
object MusicPlayer {
    var tracks: List<Media> = emptyList()
    var index = -1
    var shuffle = false
    private var mp: MediaPlayer? = null

    val current: Media? get() = tracks.getOrNull(index)
    val playing: Boolean get() = try { mp?.isPlaying == true } catch (e: Exception) { false }
    val position: Int get() = try { mp?.currentPosition ?: 0 } catch (e: Exception) { 0 }
    val duration: Int get() = try { mp?.duration ?: 0 } catch (e: Exception) { 0 }

    fun start(ctx: Context, list: List<Media>, i: Int) {
        tracks = list; index = i; load(ctx.applicationContext)
    }

    private fun load(ctx: Context) {
        mp?.release(); mp = null
        val t = current ?: return
        try {
            mp = MediaPlayer().apply {
                setAudioAttributes(AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build())
                setWakeMode(ctx, PowerManager.PARTIAL_WAKE_LOCK)
                setDataSource(ctx, t.uri)
                setOnCompletionListener { next(ctx) }
                setOnErrorListener { _, _, _ -> stop(); true }
                prepare(); start()
            }
        } catch (e: Exception) { stop() }
    }

    fun toggle() {
        val m = mp ?: return
        if (m.isPlaying) m.pause() else m.start()
    }

    fun next(ctx: Context) {
        if (tracks.isEmpty()) return
        index = if (shuffle) tracks.indices.random() else (index + 1) % tracks.size
        load(ctx.applicationContext)
    }

    fun prev(ctx: Context) {
        if (tracks.isEmpty()) return
        // restart the track if we're past 3 seconds, like a real player
        if (position > 3000) { mp?.seekTo(0); return }
        index = if (index <= 0) tracks.size - 1 else index - 1
        load(ctx.applicationContext)
    }

    fun seekTo(ms: Int) { mp?.seekTo(ms) }

    fun stop() { mp?.release(); mp = null }
}
